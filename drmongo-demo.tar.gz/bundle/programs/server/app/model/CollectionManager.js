(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// model/CollectionManager.js                                          //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
var CollectionManager = (function () {                                 //
  function CollectionManager() {                                       // 3
    babelHelpers.classCallCheck(this, CollectionManager);              //
                                                                       //
    this.collectionsNames = [];                                        // 4
  }                                                                    //
                                                                       //
  CollectionManager.prototype.mountAllCollections = (function () {     // 1
    function mountAllCollections(database) {                           // 7
      var _this = this;                                                //
                                                                       //
      var mountedCollections = {};                                     // 8
                                                                       //
      this._unmountCollections();                                      // 10
                                                                       //
      Collections.find({ database_id: database._id }).forEach(function (collection) {
        mountedCollections[collection._id] = new Mongo.Collection(collection.name);
        _this.collectionsNames.push(collection.name);                  // 14
      });                                                              //
                                                                       //
      Meteor.call('mountAllCollections', database._id);                // 17
      return mountedCollections;                                       // 18
    }                                                                  //
                                                                       //
    return mountAllCollections;                                        //
  })();                                                                //
                                                                       //
  CollectionManager.prototype.mountAllCollectionsOnServer = (function () {
    function mountAllCollectionsOnServer(databaseId) {                 // 21
      if (Meteor.isServer) {                                           // 22
        var _ret = (function () {                                      //
          var database = Databases.findOne(databaseId);                // 23
          var connection = database.connection();                      // 24
          if (!connection || !database) return {                       // 25
              v: false                                                 //
            };                                                         //
                                                                       //
          //this._unmountCollections(Meteor.server, database.collections());
          //log('>', Meteor.server);                                   //
                                                                       //
          var driver = new MongoInternals.RemoteCollectionDriver('mongodb://' + connection.host + ':' + connection.port + '/' + database.name);
                                                                       //
          Collections.find({ database_id: database._id }).forEach(function (collection) {
            if (!Mongo.Collection.get(collection.name)) {              // 33
              new Mongo.Collection(collection.name, { _driver: driver });
            }                                                          //
          });                                                          //
        })();                                                          //
                                                                       //
        if (typeof _ret === 'object') return _ret.v;                   //
      }                                                                //
    }                                                                  //
                                                                       //
    return mountAllCollectionsOnServer;                                //
  })();                                                                //
                                                                       //
  CollectionManager.prototype._unmountCollections = (function () {     // 1
    function _unmountCollections() {                                   // 40
      _.each(this.collectionsNames, function (value) {                 // 41
        delete Meteor.connection._stores[value];                       // 42
        delete Meteor.connection._methodHandlers['/' + value + '/insert'];
        delete Meteor.connection._methodHandlers['/' + value + '/remove'];
        delete Meteor.connection._methodHandlers['/' + value + '/update'];
      });                                                              //
      this.collectionsNames = [];                                      // 47
    }                                                                  //
                                                                       //
    return _unmountCollections;                                        //
  })();                                                                //
                                                                       //
  return CollectionManager;                                            //
})();                                                                  //
                                                                       //
cm = new CollectionManager();                                          // 52
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=CollectionManager.js.map
