(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// model/connections.js                                                //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Connections = new Mongo.Collection(dr.collectionNamePrefix + 'connections');
                                                                       //
Connections.friendlySlugs({                                            // 3
  slugFrom: 'name',                                                    // 5
  slugField: 'slug',                                                   // 6
  distinct: true,                                                      // 7
  updateSlug: true                                                     // 8
});                                                                    //
                                                                       //
Connections.helpers({                                                  // 12
  databases: function () {                                             // 13
    return Databases.find({ connection_id: this._id }, { sort: { name: 1 } });
  },                                                                   //
                                                                       //
  defaultDatabase: function () {                                       // 17
    return Databases.findOne({ connection_id: this._id, name: this.database });
  },                                                                   //
                                                                       //
  mainDatabase: function () {                                          // 22
    var defaultDatabase = this.defaultDatabase();                      // 23
    if (defaultDatabase) {                                             // 24
      return defaultDatabase;                                          // 25
    } else {                                                           //
      return Databases.findOne({ connection_id: this._id }, { sort: { name: 1 } });
    }                                                                  //
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=connections.js.map
