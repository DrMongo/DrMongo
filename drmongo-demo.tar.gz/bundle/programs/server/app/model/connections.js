(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// model/connections.js                                                //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Connections = new Mongo.Collection(dr.collectionNamePrefix + 'connections');
                                                                       //
Connections.allow({                                                    // 3
  insert: function () {                                                // 4
    return !dr.isDemo;                                                 // 4
  },                                                                   //
  update: function () {                                                // 5
    return !dr.isDemo;                                                 // 5
  },                                                                   //
  remove: function () {                                                // 6
    return !dr.isDemo;                                                 // 6
  }                                                                    //
});                                                                    //
                                                                       //
Connections.after.update(function (userId, doc, fieldNames, modifier, options) {
  if (fieldNames.indexOf('host') > -1 || fieldNames.indexOf('port') > -1) {
    Databases.find({ connection_id: doc._id }).forEach(function (database) {
      Collections.remove({ database_id: database._id });               // 12
    });                                                                //
    Databases.remove({ connection_id: doc._id });                      // 14
  }                                                                    //
});                                                                    //
                                                                       //
Connections.after.remove(function (userId, doc) {                      // 18
  Databases.find({ connection_id: doc._id }).forEach(function (database) {
    Collections.remove({ database_id: database._id });                 // 20
  });                                                                  //
  Databases.remove({ connection_id: doc._id });                        // 22
});                                                                    //
                                                                       //
Connections.friendlySlugs({                                            // 25
  slugFrom: 'name',                                                    // 27
  slugField: 'slug',                                                   // 28
  distinct: true,                                                      // 29
  updateSlug: true                                                     // 30
});                                                                    //
                                                                       //
Connections.helpers({                                                  // 34
  databases: function () {                                             // 35
    return Databases.find({ connection_id: this._id }, { sort: { name: 1 } });
  },                                                                   //
                                                                       //
  defaultDatabase: function () {                                       // 39
    return Databases.findOne({ connection_id: this._id, name: this.database });
  },                                                                   //
                                                                       //
  mainDatabase: function () {                                          // 44
    var defaultDatabase = this.defaultDatabase();                      // 45
    if (defaultDatabase) {                                             // 46
      return defaultDatabase;                                          // 47
    } else {                                                           //
      return Databases.findOne({ connection_id: this._id }, { sort: { name: 1 } });
    }                                                                  //
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=connections.js.map
