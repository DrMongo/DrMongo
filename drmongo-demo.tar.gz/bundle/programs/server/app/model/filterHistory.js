(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// model/filterHistory.js                                              //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
FilterHistory = new Mongo.Collection(dr.collectionNamePrefix + 'filterHistory');
                                                                       //
FilterHistory.after.insert(function (userId, doc) {                    // 3
  FilterHistory.find({ name: null }, { sort: { createdAt: 1 }, skip: 100 }).forEach(function (item) {
    FilterHistory.remove(item._id);                                    // 5
  });                                                                  //
});                                                                    //
                                                                       //
FilterHistory.allow({                                                  // 9
  insert: function () {                                                // 10
    return true;                                                       // 10
  },                                                                   //
  update: function () {                                                // 11
    return true;                                                       // 11
  },                                                                   //
  remove: function () {                                                // 12
    return true;                                                       // 12
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=filterHistory.js.map
