(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// model/collections.js                                                //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Collections = new Mongo.Collection(dr.collectionNamePrefix + 'collections');
                                                                       //
Collections.helpers({                                                  // 3
  icon: function () {                                                  // 4
    return Icons.forCollection(this.name);                             // 5
  },                                                                   //
                                                                       //
  database: function () {                                              // 8
    return Databases.findOne(this.database_id);                        // 9
  },                                                                   //
                                                                       //
  className: function () {                                             // 12
    return s(this.name).classify().value();                            // 13
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=collections.js.map
