(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// model/collections.js                                                //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Collections = new Mongo.Collection(dr.collectionNamePrefix + 'collections');
                                                                       //
Collections.allow({                                                    // 4
  insert: function () {                                                // 5
    return true;                                                       // 5
  },                                                                   //
  update: function () {                                                // 6
    return true;                                                       // 6
  },                                                                   //
  remove: function () {                                                // 7
    return true;                                                       // 7
  }                                                                    //
});                                                                    //
                                                                       //
Collections.helpers({                                                  // 10
  icon: function () {                                                  // 11
    return Icons.forCollection(this.name);                             // 12
  },                                                                   //
                                                                       //
  database: function () {                                              // 15
    return Databases.findOne(this.database_id);                        // 16
  },                                                                   //
                                                                       //
  className: function () {                                             // 19
    return s(this.name).classify().value();                            // 20
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=collections.js.map
