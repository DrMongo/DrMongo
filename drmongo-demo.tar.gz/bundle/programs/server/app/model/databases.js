(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// model/databases.js                                                  //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Databases = new Mongo.Collection(dr.collectionNamePrefix + 'databases');
                                                                       //
Databases.allow({                                                      // 3
  insert: function () {                                                // 4
    return !dr.isDemo;                                                 // 4
  },                                                                   //
  update: function () {                                                // 5
    return !dr.isDemo;                                                 // 5
  },                                                                   //
  remove: function () {                                                // 6
    return !dr.isDemo;                                                 // 6
  }                                                                    //
});                                                                    //
                                                                       //
Databases.helpers({                                                    // 9
  connection: function () {                                            // 10
    return Connections.findOne(this.connection_id);                    // 11
  },                                                                   //
                                                                       //
  collections: function () {                                           // 14
    return Collections.find({ database_id: this._id }, { sort: { name: 1 } });
  },                                                                   //
                                                                       //
  mainCollection: function () {                                        // 18
    return Collections.findOne({ database_id: this._id }, { sort: { name: 1 } });
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=databases.js.map
