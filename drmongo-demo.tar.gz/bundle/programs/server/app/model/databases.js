(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// model/databases.js                                                  //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Databases = new Mongo.Collection(dr.collectionNamePrefix + 'databases');
                                                                       //
Databases.helpers({                                                    // 3
  connection: function () {                                            // 4
    return Connections.findOne(this.connection_id);                    // 5
  },                                                                   //
                                                                       //
  collections: function () {                                           // 8
    return Collections.find({ database_id: this._id }, { sort: { name: 1 } });
  },                                                                   //
                                                                       //
  mainCollection: function () {                                        // 12
    return Collections.findOne({ database_id: this._id }, { sort: { name: 1 } });
  }                                                                    //
                                                                       //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=databases.js.map
