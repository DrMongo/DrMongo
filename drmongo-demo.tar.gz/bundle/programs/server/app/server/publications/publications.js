(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/publications/publications.js                                 //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
//Meteor.publish(null, () => {                                         //
//                                                                     //
//  console.log(Collections);                                          //
//  _.each(Collections, (value, key) => {                              //
//    console.log(key);                                                //
//    Counts.publish(this, key + '_count', value.find({}), { noReady: true });
//  });                                                                //
//  return [];                                                         //
//});                                                                  //
                                                                       //
Meteor.publish('connectionStructure', function () {                    // 11
  return [Connections.find({}), Databases.find({}), Collections.find({})];
});                                                                    //
                                                                       //
Meteor.publish('documents', function (collectionId) {                  // 19
  var collection = Collections.findOne(collectionId);                  // 20
  if (collection) {                                                    // 21
    return Mongo.Collection.get(collection.name).find({});             // 22
  }                                                                    //
});                                                                    //
                                                                       //
Meteor.publish('externalCollection', function (collectionName, selector, options, randomSeed) {
  log(randomSeed);                                                     // 27
  //log(collectionName, typeof selector, options, typeof options)      //
  if (resemblesId(selector)) {                                         // 29
    selector = eval('("' + selector + '")');                           // 30
  } else {                                                             //
    selector = eval('(' + selector + ')');                             // 32
  }                                                                    //
                                                                       //
  var c = Mongo.Collection.get(collectionName);                        // 35
  return c ? c.find(selector, options) : this.ready();                 // 36
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=publications.js.map
