(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/publications/publications.js                                 //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
//Meteor.publish(null, () => {                                         //
//                                                                     //
//  console.log(Collections);                                          //
//  _.each(Collections, (value, key) => {                              //
//    console.log(key);                                                //
//    Counts.publish(this, key + '_count', value.find({}), { noReady: true });
//  });                                                                //
//  return [];                                                         //
//});                                                                  //
                                                                       //
Meteor.publish('connectionStructure', function () {                    // 11
  return [Connections.find({}), Databases.find({}), Collections.find({}), FilterHistory.find({})];
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=publications.js.map
