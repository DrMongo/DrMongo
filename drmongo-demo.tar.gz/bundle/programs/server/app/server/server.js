(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/server.js                                                    //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
MongoClient = Meteor.npmRequire('mongodb').MongoClient;                // 1
wrappedConnect = Meteor.wrapAsync(MongoClient.connect);                // 2
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=server.js.map
