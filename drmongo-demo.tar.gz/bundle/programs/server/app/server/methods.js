(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods.js                                                   //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.methods({                                                       // 1
  createCollection: function (databaseId, collectionName) {            // 2
    var database = Databases.findOne(databaseId);                      // 3
    MongoHelpers.createCollection(database, collectionName);           // 4
                                                                       //
    // update DR cache                                                 //
    Collections.insert({                                               // 7
      database_id: databaseId,                                         // 8
      name: collectionName,                                            // 9
      updatedAt: new Date(),                                           // 10
      keep: true                                                       // 11
    });                                                                //
  },                                                                   //
                                                                       //
  updateConnectionStructure: function (connectionId) {                 // 15
    var connection = Connections.findOne(connectionId);                // 16
    if (!connection) return false;                                     // 17
    var databases = MongoHelpers.getDatabases(connection);             // 18
                                                                       //
    Databases.update({ connection_id: connectionId }, { $set: { keep: false } }, { multi: true });
    _.each(databases, function (databaseName) {                        // 21
      Databases.upsert({ connection_id: connectionId, name: databaseName }, {
        $set: {                                                        // 25
          updatedAt: new Date(),                                       // 26
          keep: true                                                   // 27
        }                                                              //
      });                                                              //
                                                                       //
      var database = Databases.findOne({                               // 32
        connection_id: connectionId,                                   // 33
        name: databaseName                                             // 34
      });                                                              //
                                                                       //
      Collections.update({ database_id: database._id }, { $set: { keep: false } }, { multi: true });
      var collections = MongoHelpers.getCollections(connection, databaseName);
      _.each(collections, function (collectionName) {                  // 39
        Collections.upsert({ database_id: database._id, name: collectionName }, {
          $set: {                                                      // 43
            updatedAt: new Date(),                                     // 44
            keep: true                                                 // 45
          }                                                            //
        });                                                            //
      });                                                              //
      Collections.remove({ database_id: database._id, keep: false });  // 50
    });                                                                //
    Databases.remove({ connection_id: connectionId, keep: false });    // 53
    return true;                                                       // 54
  },                                                                   //
  findCollectionForDocumentId: function (databaseId, documentId) {     // 56
    var db = connectDatabase(databaseId);                              // 57
                                                                       //
    var foundCollection = null;                                        // 59
                                                                       //
    var selector = { _id: documentId };                                // 61
                                                                       //
    var collectionNamesWrapper = Meteor.wrapAsync(function (cb) {      // 63
      db.listCollections().toArray(function (error, response) {        // 64
        cb(error, response);                                           // 65
      });                                                              //
    });                                                                //
    var collections = collectionNamesWrapper();                        // 68
                                                                       //
    var c;                                                             // 70
    var collectionFindWrapper = Meteor.wrapAsync(function (cb) {       // 71
      c.find(selector).toArray(function (error, response) {            // 72
        cb(error, response);                                           // 73
      });                                                              //
    });                                                                //
                                                                       //
    _.each(collections, function (collection) {                        // 77
      if (foundCollection) return false;                               // 78
                                                                       //
      c = db.collection(collection.name);                              // 80
                                                                       //
      var result = collectionFindWrapper();                            // 82
      if (result.length == 1) foundCollection = collection.name;       // 83
    });                                                                //
                                                                       //
    db.close();                                                        // 86
    return foundCollection;                                            // 87
  },                                                                   //
  getDocuments: function (databaseId, collectionName, filter, pagination) {
    pagination = pagination || 0;                                      // 90
                                                                       //
    var db = connectDatabase(databaseId);                              // 92
    var collection = db.collection(collectionName);                    // 93
                                                                       //
    var collectionInfo = Collections.findOne({ database_id: databaseId, name: collectionName });
    collectionInfo.paginationLimit = collectionInfo.paginationLimit || 20;
                                                                       //
    if (!collectionInfo) return false;                                 // 98
                                                                       //
    if (resemblesId(filter)) {                                         // 100
      var selector = { _id: filter };                                  // 101
      var options = {};                                                // 102
    } else {                                                           //
      try {                                                            // 104
        filter = eval('([' + filter + '])');                           // 105
      } catch (error) {                                                //
        return false;                                                  // 109
      }                                                                //
                                                                       //
      var selector = filter[0] || {};                                  // 112
      var options = filter[1] || {};                                   // 113
    }                                                                  //
                                                                       //
    var collectionCountWrapper = Meteor.wrapAsync(function (cb) {      // 116
      collection.find(selector, options).count(function (error, response) {
        cb(error, response);                                           // 118
      });                                                              //
    });                                                                //
                                                                       //
    var docsCount = collectionCountWrapper();                          // 122
                                                                       //
    if (!options.skip) {                                               // 124
      options.skip = pagination * collectionInfo.paginationLimit;      // 125
    }                                                                  //
    if (!options.limit) {                                              // 127
      options.limit = collectionInfo.paginationLimit;                  // 128
    }                                                                  //
                                                                       //
    var docs = collection.find(selector, options.fields || {}).sort(options.sort || {}).skip(options.skip || 0).limit(options.limit || 0);
                                                                       //
    var collectionToArrayWrapper = Meteor.wrapAsync(function (cb) {    // 137
      docs.toArray(function (error, response) {                        // 138
        cb(error, response);                                           // 139
      });                                                              //
    });                                                                //
                                                                       //
    docs = collectionToArrayWrapper();                                 // 143
                                                                       //
    db.close();                                                        // 145
    return {                                                           // 146
      docs: docs,                                                      // 147
      count: docsCount                                                 // 148
    };                                                                 //
  },                                                                   //
  insertDocument: function (collectionId, data) {                      // 151
    var collection = Collections.findOne(collectionId);                // 152
    var database = collection.database();                              // 153
                                                                       //
    var db = connectDatabase(database._id);                            // 155
    var dbCollection = db.collection(collection.name);                 // 156
                                                                       //
    var insertWrapper = Meteor.wrapAsync(function (cb) {               // 158
      dbCollection.insertOne(data, function (error, response) {        // 159
        cb(error, response);                                           // 160
      });                                                              //
    });                                                                //
                                                                       //
    var insertResult = insertWrapper();                                // 164
    db.close();                                                        // 165
                                                                       //
    return insertResult;                                               // 167
  },                                                                   //
  updateDocument: function (collectionId, documentId, data) {          // 169
    var collection = Collections.findOne(collectionId);                // 170
    var database = collection.database();                              // 171
                                                                       //
    var db = connectDatabase(database._id);                            // 173
    var dbCollection = db.collection(collection.name);                 // 174
                                                                       //
    delete data._id;                                                   // 176
                                                                       //
    var updateWrapper = Meteor.wrapAsync(function (cb) {               // 178
      dbCollection.updateOne({ _id: documentId }, data, function (error, response) {
        cb(error, response);                                           // 180
      });                                                              //
    });                                                                //
                                                                       //
    var updatedCount = updateWrapper();                                // 184
    db.close();                                                        // 185
                                                                       //
    return updatedCount;                                               // 187
  },                                                                   //
  duplicateDocument: function (collectionId, documentId) {             // 189
    var collection = Collections.findOne(collectionId);                // 190
    var database = collection.database();                              // 191
                                                                       //
    var db = connectDatabase(database._id);                            // 193
    var dbCollection = db.collection(collection.name);                 // 194
                                                                       //
    var findWrapper = Meteor.wrapAsync(function (cb) {                 // 196
      dbCollection.findOne({ _id: documentId }, function (error, response) {
        cb(error, response);                                           // 198
      });                                                              //
    });                                                                //
                                                                       //
    var sourceDocument = findWrapper();                                // 202
    if (!sourceDocument) return false;                                 // 203
                                                                       //
    delete sourceDocument._id;                                         // 205
                                                                       //
    var insertWrapper = Meteor.wrapAsync(function (cb) {               // 207
      dbCollection.insertOne(sourceDocument, function (error, response) {
        cb(error, response);                                           // 209
      });                                                              //
    });                                                                //
                                                                       //
    var insertResult = insertWrapper();                                // 213
    db.close();                                                        // 214
                                                                       //
    return insertResult;                                               // 216
  },                                                                   //
  removeDocument: function (collectionId, documentId) {                // 218
    var collection = Collections.findOne(collectionId);                // 219
    var database = collection.database();                              // 220
                                                                       //
    var db = connectDatabase(database._id);                            // 222
    var dbCollection = db.collection(collection.name);                 // 223
                                                                       //
    var deleteWrapper = Meteor.wrapAsync(function (cb) {               // 225
      dbCollection.findOneAndDelete({ _id: documentId }, function (error, response) {
        cb(error, response);                                           // 227
      });                                                              //
    });                                                                //
                                                                       //
    var result = deleteWrapper();                                      // 231
    db.close();                                                        // 232
                                                                       //
    return result;                                                     // 234
  },                                                                   //
  changeDatabase: function () {                                        // 236
    if (Meteor.isServer) {                                             // 237
      //log('exiting')                                                 //
      //process.exit();                                                //
    } else {                                                           //
        location.reload();                                             // 241
      }                                                                //
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=methods.js.map
