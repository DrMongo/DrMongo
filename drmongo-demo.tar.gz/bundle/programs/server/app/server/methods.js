(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods.js                                                   //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.methods({                                                       // 1
  mountCollection: function (collectionId) {                           // 2
    check(collectionId, String);                                       // 3
                                                                       //
    cm.mountCollectionOnServer(collectionId);                          // 5
  },                                                                   //
  mountAllCollections: function (databaseId) {                         // 7
    check(databaseId, String);                                         // 8
                                                                       //
    cm.mountAllCollectionsOnServer(databaseId);                        // 10
  },                                                                   //
                                                                       //
  createCollection: function (databaseId, collectionName) {            // 13
    var database = Databases.findOne(databaseId);                      // 14
    MongoHelpers.createCollection(database, collectionName);           // 15
                                                                       //
    // update DR cache                                                 //
    Collections.insert({                                               // 18
      database_id: databaseId,                                         // 19
      name: collectionName,                                            // 20
      updatedAt: new Date(),                                           // 21
      keep: true                                                       // 22
    });                                                                //
  },                                                                   //
                                                                       //
  updateConnectionStructure: function (connectionId) {                 // 26
    var connection = Connections.findOne(connectionId);                // 27
    if (!connection) return false;                                     // 28
    var databases = MongoHelpers.getDatabases(connection);             // 29
                                                                       //
    Databases.update({ connection_id: connectionId }, { $set: { keep: false } }, { multi: true });
    _.each(databases, function (databaseName) {                        // 32
      Databases.upsert({ connection_id: connectionId, name: databaseName }, {
        $set: {                                                        // 36
          updatedAt: new Date(),                                       // 37
          keep: true                                                   // 38
        }                                                              //
      });                                                              //
                                                                       //
      var database = Databases.findOne({                               // 43
        connection_id: connectionId,                                   // 44
        name: databaseName                                             // 45
      });                                                              //
                                                                       //
      Collections.update({ database_id: database._id }, { $set: { keep: false } }, { multi: true });
      var collections = MongoHelpers.getCollections(connection, databaseName);
      _.each(collections, function (collectionName) {                  // 50
        Collections.upsert({ database_id: database._id, name: collectionName }, {
          $set: {                                                      // 54
            updatedAt: new Date(),                                     // 55
            keep: true                                                 // 56
          }                                                            //
        });                                                            //
      });                                                              //
      Collections.remove({ database_id: database._id, keep: false });  // 61
    });                                                                //
    Databases.remove({ connection_id: connectionId, keep: false });    // 64
    return true;                                                       // 65
  },                                                                   //
  findCollectionForDocumentId: function (databaseId, documentId) {     // 67
    var database = Databases.findOne(databaseId);                      // 68
    var foundCollection = null;                                        // 69
    Collections.find({ database_id: database._id }).forEach(function (collection) {
      if (foundCollection) return false;                               // 71
      var c = Mongo.Collection.get(collection.name);                   // 72
      if (c) {                                                         // 73
        var document = c.findOne(documentId);                          // 74
        if (document) foundCollection = collection.name;               // 75
      }                                                                //
    });                                                                //
    return foundCollection;                                            // 78
  }                                                                    //
                                                                       //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=methods.js.map
