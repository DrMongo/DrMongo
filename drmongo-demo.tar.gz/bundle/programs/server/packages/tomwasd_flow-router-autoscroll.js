(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var FlowRouter = Package['kadira:flow-router'].FlowRouter;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/tomwasd_flow-router-autoscroll/packages/tomwasd_flow-rou //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['tomwasd:flow-router-autoscroll'] = {};

})();

//# sourceMappingURL=tomwasd_flow-router-autoscroll.js.map
