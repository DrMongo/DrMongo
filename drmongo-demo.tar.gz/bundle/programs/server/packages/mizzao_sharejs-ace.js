(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var ShareJS = Package['mizzao:sharejs'].ShareJS;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mizzao:sharejs-ace'] = {};

})();

//# sourceMappingURL=mizzao_sharejs-ace.js.map
