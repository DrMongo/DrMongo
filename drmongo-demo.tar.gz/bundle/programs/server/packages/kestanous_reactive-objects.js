(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var _ = Package.underscore._;

/* Package-scope variables */
var ReactiveObjects, key, proxyArray, keys;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/kestanous_reactive-objects/packages/kestanous_reactive-objects.js                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
(function () {                                                                                                         // 1
                                                                                                                       // 2
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/kestanous:reactive-objects/lib/reactive-objects.js                                                      //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
ReactiveObjects = function (properties) { //instance                                                                // 1
  var self = this;                                                                                                  // 2
                                                                                                                    // 3
  self.ReactiveConfig = {};                                                                                         // 4
  self.ReactiveFunctions = {};                                                                                      // 5
                                                                                                                    // 6
  self.ReactiveFunctions.addProperty = function (name, value) {                                                     // 7
    self.ReactiveConfig[name] = {                                                                                   // 8
      value: value,                                                                                                 // 9
      type: self.constructor.getPropertyType(value),                                                                // 10
      deps: new Deps.Dependency,                                                                                    // 11
    };                                                                                                              // 12
    Object.defineProperty(self, name, {                                                                             // 13
      configurable: true, //allow for removal of get/set later                                                      // 14
      get: function () {                                                                                            // 15
        return self.constructor.getProxies(                                                                         // 16
          self.ReactiveConfig[name].value,                                                                          // 17
          self.ReactiveConfig[name].type,                                                                           // 18
          self.ReactiveConfig[name].deps                                                                            // 19
        )                                                                                                           // 20
      },                                                                                                            // 21
                                                                                                                    // 22
      set: function (value) {                                                                                       // 23
        self.ReactiveConfig[name].value = value;                                                                    // 24
        self.ReactiveConfig[name].type = self.constructor.getPropertyType(value);                                   // 25
        self.ReactiveConfig[name].deps.changed();                                                                   // 26
      }                                                                                                             // 27
    });                                                                                                             // 28
  };                                                                                                                // 29
                                                                                                                    // 30
  if (!properties) {return} //Built and no work left                                                                // 31
  _.keys(properties).forEach(function (propertyName) {                                                              // 32
    self.ReactiveFunctions.addProperty(propertyName, properties[propertyName])                                      // 33
  });                                                                                                               // 34
};                                                                                                                  // 35
                                                                                                                    // 36
                                                                                                                    // 37
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       // 47
}).call(this);                                                                                                         // 48
                                                                                                                       // 49
                                                                                                                       // 50
                                                                                                                       // 51
                                                                                                                       // 52
                                                                                                                       // 53
                                                                                                                       // 54
(function () {                                                                                                         // 55
                                                                                                                       // 56
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/kestanous:reactive-objects/lib/model-methods.js                                                         //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
ReactiveObjects.getProxies = function (value,type,deps) {                                                           // 1
  return this.proxies[type](value, deps);                                                                           // 2
}                                                                                                                   // 3
                                                                                                                    // 4
ReactiveObjects.getPropertyType = function (value) {                                                                // 5
  if (this.disableDynamicProxies) return 'default'                                                                  // 6
  if (_.isArray(value)) return 'array'                                                                              // 7
  return 'default'                                                                                                  // 8
}                                                                                                                   // 9
ReactiveObjects.isReactiveProperty = function (obj, name) {                                                         // 10
  if (!obj.ReactiveConfig) {return false}                                                                           // 11
  if (obj.ReactiveConfig[name]) {return true} else {return false}                                                   // 12
}                                                                                                                   // 13
ReactiveObjects.isReactiveObject = function (obj) {                                                                 // 14
  if (obj.ReactiveConfig) {                                                                                         // 15
    return true                                                                                                     // 16
  }                                                                                                                 // 17
}                                                                                                                   // 18
                                                                                                                    // 19
ReactiveObjects.removeProperty = function (obj, name) {                                                             // 20
  if (!this.isReactiveProperty(obj, name)) {return} //Nothing to do, would create a property by that name otherwise // 21
                                                                                                                    // 22
  var backup = obj.ReactiveConfig[name].value                                                                       // 23
                                                                                                                    // 24
  //this is the same config as a default object property                                                            // 25
  Object.defineProperty(obj, name, {value : backup, writable : true, configurable : true, enumerable : true});      // 26
                                                                                                                    // 27
  delete obj.ReactiveConfig[name]                                                                                   // 28
  return obj                                                                                                        // 29
}                                                                                                                   // 30
                                                                                                                    // 31
ReactiveObjects.removeObject = function (obj) {                                                                     // 32
  if (!this.isReactiveObject(obj)) {return}                                                                         // 33
                                                                                                                    // 34
  for(key in obj.ReactiveConfig) {                                                                                  // 35
    var backup = obj.ReactiveConfig[key].value                                                                      // 36
    Object.defineProperty(obj, key, {value : backup, writable : true, configurable : true, enumerable : true});     // 37
  }                                                                                                                 // 38
  delete obj.ReactiveConfig                                                                                         // 39
  delete obj.ReactiveFunctions                                                                                      // 40
  return obj                                                                                                        // 41
}                                                                                                                   // 42
                                                                                                                    // 43
                                                                                                                    // 44
ReactiveObjects.disableDynamicProxies = false                                                                       // 45
                                                                                                                    // 46
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       // 110
}).call(this);                                                                                                         // 111
                                                                                                                       // 112
                                                                                                                       // 113
                                                                                                                       // 114
                                                                                                                       // 115
                                                                                                                       // 116
                                                                                                                       // 117
(function () {                                                                                                         // 118
                                                                                                                       // 119
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// packages/kestanous:reactive-objects/lib/proxies.js                                                               //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
ReactiveObjects.proxies = {                                                                                         // 1
  'default': function (value, deps) {                                                                               // 2
    deps.depend();                                                                                                  // 3
    return value                                                                                                    // 4
  },                                                                                                                // 5
  'array': function (array, deps) {                                                                                 // 6
    proxyArray = []                                                                                                 // 7
    keys = [                                                                                                        // 8
      'push',                                                                                                       // 9
      'pop',                                                                                                        // 10
      'reverse',                                                                                                    // 11
      'shift',                                                                                                      // 12
      'sort',                                                                                                       // 13
      'splice',                                                                                                     // 14
      'unshift'                                                                                                     // 15
    ]                                                                                                               // 16
                                                                                                                    // 17
    keys.forEach(function (key) {                                                                                   // 18
      proxyArray[key] = function () {                                                                               // 19
        var output = array[key].apply(array, arguments)                                                             // 20
        deps.changed();                                                                                             // 21
        return output;                                                                                              // 22
      }                                                                                                             // 23
    });                                                                                                             // 24
                                                                                                                    // 25
    deps.depend();                                                                                                  // 26
    return _.defaults(proxyArray, array)                                                                            // 27
  }                                                                                                                 // 28
}                                                                                                                   // 29
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       // 156
}).call(this);                                                                                                         // 157
                                                                                                                       // 158
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['kestanous:reactive-objects'] = {
  ReactiveObjects: ReactiveObjects
};

})();

//# sourceMappingURL=kestanous_reactive-objects.js.map
