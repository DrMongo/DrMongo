(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;
var check = Package.check.check;
var Match = Package.check.Match;
var CollectionHooks = Package['matb33:collection-hooks'].CollectionHooks;

/* Package-scope variables */
var __coffeescriptShare;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/todda00_friendly-slugs/packages/todda00_friendly-slugs.js                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
(function () {                                                                                                       // 1
                                                                                                                     // 2
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/todda00:friendly-slugs/slugs.coffee.js                                                                   //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var Mongo, slugify;                                                                                                  // 10
                                                                                                                     // 11
if (typeof Mongo === "undefined") {                                                                                  // 12
  Mongo = {};                                                                                                        // 13
  Mongo.Collection = Meteor.Collection;                                                                              // 14
}                                                                                                                    // 15
                                                                                                                     // 16
Mongo.Collection.prototype.friendlySlugs = function(options) {                                                       // 17
  var collection, fsDebug, runSlug;                                                                                  // 18
  if (options == null) {                                                                                             // 19
    options = {};                                                                                                    // 20
  }                                                                                                                  // 21
  collection = this;                                                                                                 // 22
  if (!_.isArray(options)) {                                                                                         // 23
    options = [options];                                                                                             // 24
  }                                                                                                                  // 25
  _.each(options, function(opts) {                                                                                   // 26
    var defaults, fields;                                                                                            // 27
    if (_.isString(opts)) {                                                                                          // 28
      opts = {                                                                                                       // 29
        slugFrom: opts                                                                                               // 30
      };                                                                                                             // 31
    }                                                                                                                // 32
    defaults = {                                                                                                     // 33
      slugFrom: 'name',                                                                                              // 34
      slugField: 'slug',                                                                                             // 35
      distinct: true,                                                                                                // 36
      updateSlug: true,                                                                                              // 37
      createOnUpdate: true,                                                                                          // 38
      debug: false,                                                                                                  // 39
      transliteration: [                                                                                             // 40
        {                                                                                                            // 41
          from: 'àáâäãа',                                                                                            // 42
          to: 'a'                                                                                                    // 43
        }, {                                                                                                         // 44
          from: 'б',                                                                                                 // 45
          to: 'b'                                                                                                    // 46
        }, {                                                                                                         // 47
          from: 'ç',                                                                                                 // 48
          to: 'c'                                                                                                    // 49
        }, {                                                                                                         // 50
          from: 'д',                                                                                                 // 51
          to: 'd'                                                                                                    // 52
        }, {                                                                                                         // 53
          from: 'èéêëẽэе',                                                                                           // 54
          to: 'e'                                                                                                    // 55
        }, {                                                                                                         // 56
          from: 'ф',                                                                                                 // 57
          to: 'f'                                                                                                    // 58
        }, {                                                                                                         // 59
          from: 'г',                                                                                                 // 60
          to: 'g'                                                                                                    // 61
        }, {                                                                                                         // 62
          from: 'х',                                                                                                 // 63
          to: 'h'                                                                                                    // 64
        }, {                                                                                                         // 65
          from: 'ìíîïи',                                                                                             // 66
          to: 'i'                                                                                                    // 67
        }, {                                                                                                         // 68
          from: 'к',                                                                                                 // 69
          to: 'k'                                                                                                    // 70
        }, {                                                                                                         // 71
          from: 'л',                                                                                                 // 72
          to: 'l'                                                                                                    // 73
        }, {                                                                                                         // 74
          from: 'м',                                                                                                 // 75
          to: 'm'                                                                                                    // 76
        }, {                                                                                                         // 77
          from: 'ñн',                                                                                                // 78
          to: 'n'                                                                                                    // 79
        }, {                                                                                                         // 80
          from: 'òóôöõо',                                                                                            // 81
          to: 'o'                                                                                                    // 82
        }, {                                                                                                         // 83
          from: 'п',                                                                                                 // 84
          to: 'p'                                                                                                    // 85
        }, {                                                                                                         // 86
          from: 'р',                                                                                                 // 87
          to: 'r'                                                                                                    // 88
        }, {                                                                                                         // 89
          from: 'с',                                                                                                 // 90
          to: 's'                                                                                                    // 91
        }, {                                                                                                         // 92
          from: 'т',                                                                                                 // 93
          to: 't'                                                                                                    // 94
        }, {                                                                                                         // 95
          from: 'ùúûüу',                                                                                             // 96
          to: 'u'                                                                                                    // 97
        }, {                                                                                                         // 98
          from: 'в',                                                                                                 // 99
          to: 'v'                                                                                                    // 100
        }, {                                                                                                         // 101
          from: 'йы',                                                                                                // 102
          to: 'y'                                                                                                    // 103
        }, {                                                                                                         // 104
          from: 'з',                                                                                                 // 105
          to: 'z'                                                                                                    // 106
        }, {                                                                                                         // 107
          from: 'æ',                                                                                                 // 108
          to: 'ae'                                                                                                   // 109
        }, {                                                                                                         // 110
          from: 'ч',                                                                                                 // 111
          to: 'ch'                                                                                                   // 112
        }, {                                                                                                         // 113
          from: 'щ',                                                                                                 // 114
          to: 'sch'                                                                                                  // 115
        }, {                                                                                                         // 116
          from: 'ш',                                                                                                 // 117
          to: 'sh'                                                                                                   // 118
        }, {                                                                                                         // 119
          from: 'ц',                                                                                                 // 120
          to: 'ts'                                                                                                   // 121
        }, {                                                                                                         // 122
          from: 'я',                                                                                                 // 123
          to: 'ya'                                                                                                   // 124
        }, {                                                                                                         // 125
          from: 'ю',                                                                                                 // 126
          to: 'yu'                                                                                                   // 127
        }, {                                                                                                         // 128
          from: 'ж',                                                                                                 // 129
          to: 'zh'                                                                                                   // 130
        }, {                                                                                                         // 131
          from: 'ъь',                                                                                                // 132
          to: ''                                                                                                     // 133
        }                                                                                                            // 134
      ]                                                                                                              // 135
    };                                                                                                               // 136
    _.defaults(opts, defaults);                                                                                      // 137
    fields = {                                                                                                       // 138
      slugFrom: String,                                                                                              // 139
      slugField: String,                                                                                             // 140
      distinct: Boolean,                                                                                             // 141
      updateSlug: Boolean,                                                                                           // 142
      createOnUpdate: Boolean,                                                                                       // 143
      debug: Boolean                                                                                                 // 144
    };                                                                                                               // 145
    check(opts, Match.ObjectIncluding(fields));                                                                      // 146
    collection.before.insert(function(userId, doc) {                                                                 // 147
      runSlug(doc, opts);                                                                                            // 148
    });                                                                                                              // 149
    collection.before.update(function(userId, doc, fieldNames, modifier, options) {                                  // 150
      var cleanModifier, slugFromChanged;                                                                            // 151
      cleanModifier = function() {                                                                                   // 152
        if (_.isEmpty(modifier.$set)) {                                                                              // 153
          return delete modifier.$set;                                                                               // 154
        }                                                                                                            // 155
      };                                                                                                             // 156
      options = options || {};                                                                                       // 157
      if (options.multi) {                                                                                           // 158
        fsDebug(opts, "multi doc update attempted, can't update slugs this way, leaving.");                          // 159
        return true;                                                                                                 // 160
      }                                                                                                              // 161
      modifier = modifier || {};                                                                                     // 162
      modifier.$set = modifier.$set || {};                                                                           // 163
      if ((doc[opts.slugFrom] == null) && (modifier.$set[opts.slugFrom] == null)) {                                  // 164
        cleanModifier();                                                                                             // 165
        return true;                                                                                                 // 166
      }                                                                                                              // 167
      slugFromChanged = false;                                                                                       // 168
      if (modifier.$set[opts.slugFrom] != null) {                                                                    // 169
        if (doc[opts.slugFrom] !== modifier.$set[opts.slugFrom]) {                                                   // 170
          slugFromChanged = true;                                                                                    // 171
        }                                                                                                            // 172
      }                                                                                                              // 173
      fsDebug(opts, slugFromChanged, 'slugFromChanged');                                                             // 174
      if ((doc[opts.slugField] == null) && opts.createOnUpdate) {                                                    // 175
        fsDebug(opts, 'Update: Slug Field is missing and createOnUpdate is set to true');                            // 176
        if (slugFromChanged) {                                                                                       // 177
          fsDebug(opts, 'slugFrom field has changed, runSlug with modifier');                                        // 178
          runSlug(doc, opts, modifier);                                                                              // 179
        } else {                                                                                                     // 180
          fsDebug(opts, 'runSlug to create');                                                                        // 181
          runSlug(doc, opts, modifier, true);                                                                        // 182
          cleanModifier();                                                                                           // 183
          return true;                                                                                               // 184
        }                                                                                                            // 185
      } else {                                                                                                       // 186
        if (opts.updateSlug === false) {                                                                             // 187
          fsDebug(opts, 'updateSlug is false, nothing to do.');                                                      // 188
          cleanModifier();                                                                                           // 189
          return true;                                                                                               // 190
        }                                                                                                            // 191
        if (doc[opts.slugFrom] === modifier.$set[opts.slugFrom]) {                                                   // 192
          fsDebug(opts, 'slugFrom field has not changed, nothing to do.');                                           // 193
          cleanModifier();                                                                                           // 194
          return true;                                                                                               // 195
        }                                                                                                            // 196
        runSlug(doc, opts, modifier);                                                                                // 197
        cleanModifier();                                                                                             // 198
        return true;                                                                                                 // 199
      }                                                                                                              // 200
      cleanModifier();                                                                                               // 201
      return true;                                                                                                   // 202
    });                                                                                                              // 203
  });                                                                                                                // 204
  runSlug = function(doc, opts, modifier, create) {                                                                  // 205
    var baseField, fieldSelector, finalSlug, from, index, indexField, limitSelector, result, slugBase, sortSelector;
    if (modifier == null) {                                                                                          // 207
      modifier = false;                                                                                              // 208
    }                                                                                                                // 209
    if (create == null) {                                                                                            // 210
      create = false;                                                                                                // 211
    }                                                                                                                // 212
    fsDebug(opts, 'Begin runSlug');                                                                                  // 213
    fsDebug(opts, opts, 'Options');                                                                                  // 214
    fsDebug(opts, modifier, 'Modifier');                                                                             // 215
    fsDebug(opts, create, 'Create');                                                                                 // 216
    from = create || !modifier ? doc[opts.slugFrom] : modifier.$set[opts.slugFrom];                                  // 217
    fsDebug(opts, from, 'Slugging From');                                                                            // 218
    slugBase = slugify(from, opts.transliteration);                                                                  // 219
    if (!slugBase) {                                                                                                 // 220
      return false;                                                                                                  // 221
    }                                                                                                                // 222
    fsDebug(opts, slugBase, 'SlugBase before reduction');                                                            // 223
    if (opts.distinct) {                                                                                             // 224
      slugBase = slugBase.replace(/(-\d+)+$/, '');                                                                   // 225
      fsDebug(opts, slugBase, 'SlugBase after reduction');                                                           // 226
      baseField = "friendlySlugs." + opts.slugField + ".base";                                                       // 227
      indexField = "friendlySlugs." + opts.slugField + ".index";                                                     // 228
      fieldSelector = {};                                                                                            // 229
      fieldSelector[baseField] = slugBase;                                                                           // 230
      sortSelector = {};                                                                                             // 231
      sortSelector[indexField] = -1;                                                                                 // 232
      limitSelector = {};                                                                                            // 233
      limitSelector[indexField] = 1;                                                                                 // 234
      result = collection.findOne(fieldSelector, {                                                                   // 235
        sort: sortSelector,                                                                                          // 236
        fields: limitSelector,                                                                                       // 237
        limit: 1                                                                                                     // 238
      });                                                                                                            // 239
      fsDebug(opts, result, 'Highest indexed base found');                                                           // 240
      if ((result == null) || (result.friendlySlugs == null) || (result.friendlySlugs[opts.slugField] == null) || (result.friendlySlugs[opts.slugField].index == null)) {
        index = 0;                                                                                                   // 242
      } else {                                                                                                       // 243
        index = result.friendlySlugs[opts.slugField].index + 1;                                                      // 244
      }                                                                                                              // 245
      if (index === 0) {                                                                                             // 246
        finalSlug = slugBase;                                                                                        // 247
      } else {                                                                                                       // 248
        finalSlug = slugBase + '-' + index;                                                                          // 249
      }                                                                                                              // 250
    } else {                                                                                                         // 251
      index = false;                                                                                                 // 252
      finalSlug = slugBase;                                                                                          // 253
    }                                                                                                                // 254
    fsDebug(opts, finalSlug, 'finalSlug');                                                                           // 255
    if (modifier || create) {                                                                                        // 256
      fsDebug(opts, 'Set to modify or create slug on update');                                                       // 257
      modifier = modifier || {};                                                                                     // 258
      modifier.$set = modifier.$set || {};                                                                           // 259
      modifier.$set.friendlySlugs = doc.friendlySlugs || {};                                                         // 260
      modifier.$set.friendlySlugs[opts.slugField] = modifier.$set.friendlySlugs[opts.slugField] || {};               // 261
      modifier.$set.friendlySlugs[opts.slugField].base = slugBase;                                                   // 262
      modifier.$set.friendlySlugs[opts.slugField].index = index;                                                     // 263
      modifier.$set[opts.slugField] = finalSlug;                                                                     // 264
      fsDebug(opts, modifier, 'Final Modifier');                                                                     // 265
    } else {                                                                                                         // 266
      fsDebug(opts, 'Set to update');                                                                                // 267
      doc.friendlySlugs = doc.friendlySlugs || {};                                                                   // 268
      doc.friendlySlugs[opts.slugField] = doc.friendlySlugs[opts.slugField] || {};                                   // 269
      doc.friendlySlugs[opts.slugField].base = slugBase;                                                             // 270
      doc.friendlySlugs[opts.slugField].index = index;                                                               // 271
      doc[opts.slugField] = finalSlug;                                                                               // 272
      fsDebug(opts, doc, 'Final Doc');                                                                               // 273
    }                                                                                                                // 274
    return true;                                                                                                     // 275
  };                                                                                                                 // 276
  return fsDebug = function(opts, item, label) {                                                                     // 277
    if (label == null) {                                                                                             // 278
      label = '';                                                                                                    // 279
    }                                                                                                                // 280
    if (!opts.debug) {                                                                                               // 281
      return;                                                                                                        // 282
    }                                                                                                                // 283
    if (typeof item === 'object') {                                                                                  // 284
      console.log("friendlySlugs DEBUG: " + label + '↓');                                                            // 285
      return console.log(item);                                                                                      // 286
    } else {                                                                                                         // 287
      return console.log("friendlySlugs DEBUG: " + label + '= ' + item);                                             // 288
    }                                                                                                                // 289
  };                                                                                                                 // 290
};                                                                                                                   // 291
                                                                                                                     // 292
slugify = function(text, transliteration) {                                                                          // 293
  if (text == null) {                                                                                                // 294
    return false;                                                                                                    // 295
  }                                                                                                                  // 296
  if (text.length < 1) {                                                                                             // 297
    return false;                                                                                                    // 298
  }                                                                                                                  // 299
  text = text.toString().toLowerCase();                                                                              // 300
  _.each(transliteration, function(item) {                                                                           // 301
    return text = text.replace(new RegExp('[' + item.from + ']', 'g'), item.to);                                     // 302
  });                                                                                                                // 303
  return text.replace(/'/g, '').replace(/[^0-9a-z-]/g, '-').replace(/\-\-+/g, '-').replace(/^-+/, '').replace(/-+$/, '');
};                                                                                                                   // 305
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     // 307
}).call(this);                                                                                                       // 308
                                                                                                                     // 309
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['todda00:friendly-slugs'] = {};

})();

//# sourceMappingURL=todda00_friendly-slugs.js.map
