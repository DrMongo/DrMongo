(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var ECMAScript = Package.ecmascript.ECMAScript;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var babelHelpers = Package['babel-runtime'].babelHelpers;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var MongoHelpers;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                     //
// packages/drmongo_mongo-helpers/server/MongoHelpers.js                                               //
//                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                       //
var getConnection = function (data, cb) {                                                              // 1
  var connection = data.connection;                                                                    // 2
  var database = data.database || null;                                                                // 3
  var url = 'mongodb://' + connection.host + ':' + connection.port + (database ? '/' + database : '');
                                                                                                       //
  MongoInternals.NpmModules.mongodb.module(url, function (error, db) {                                 // 6
    if (error) {                                                                                       // 7
      throw new Error(error.message);                                                                  // 8
    } else {                                                                                           //
      cb(null, db);                                                                                    // 10
    }                                                                                                  //
  });                                                                                                  //
};                                                                                                     //
                                                                                                       //
MongoHelpers = {                                                                                       // 16
                                                                                                       //
  getDatabases: function (connection) {                                                                // 18
    var getConnectionWrapper = Meteor.wrapAsync(getConnection);                                        // 19
    var db = getConnectionWrapper({ connection: connection });                                         // 20
                                                                                                       //
    // Use the admin database for the operation                                                        //
    var adminDb = db.admin();                                                                          // 23
                                                                                                       //
    // Get all the available databases                                                                 //
    var listDatabasesWrapper = Meteor.wrapAsync(adminDb.listDatabases);                                // 26
    var databases = listDatabasesWrapper();                                                            // 27
                                                                                                       //
    db.close();                                                                                        // 29
                                                                                                       //
    var databaseNames = [];                                                                            // 31
    _.each(databases.databases, function (value) {                                                     // 32
      if (value.name == 'local' || value.name == 'admin') return false;                                // 33
      if (dr.isDemo == true && value.name.indexOf('dummy') !== 0) return false;                        // 34
      databaseNames.push(value.name);                                                                  // 35
    });                                                                                                //
                                                                                                       //
    return databaseNames;                                                                              // 38
  },                                                                                                   //
                                                                                                       //
  getCollections: function (connection, database) {                                                    // 41
    var getConnectionWrapper = Meteor.wrapAsync(getConnection);                                        // 42
    var db = getConnectionWrapper({ connection: connection, database: database });                     // 43
                                                                                                       //
    var collectionNamesWrapper = Meteor.wrapAsync(function (cb) {                                      // 46
      db.collectionNames(function (error, response) {                                                  // 47
        cb(error, response);                                                                           // 48
      });                                                                                              //
    });                                                                                                //
    var collections = collectionNamesWrapper();                                                        // 51
                                                                                                       //
    db.close();                                                                                        // 53
    var collectionNames = [];                                                                          // 54
    _.each(collections, function (value) {                                                             // 55
      if (value.name == 'system.indexes') return false;                                                // 56
      collectionNames.push(value.name);                                                                // 57
    });                                                                                                //
    return collectionNames;                                                                            // 59
  },                                                                                                   //
                                                                                                       //
  createCollection: function (database, collectionName) {                                              // 62
    var getConnectionWrapper = Meteor.wrapAsync(getConnection);                                        // 63
    var db = getConnectionWrapper({ connection: database.connection(), database: database.name });     // 64
                                                                                                       //
    var createCollectionWrapper = Meteor.wrapAsync(function (cb) {                                     // 66
      db.createCollection(collectionName, function (error, response) {                                 // 67
        cb(null, true);                                                                                // 68
      });                                                                                              //
    });                                                                                                //
                                                                                                       //
    var response = createCollectionWrapper();                                                          // 72
                                                                                                       //
    return response;                                                                                   // 74
  }                                                                                                    //
                                                                                                       //
};                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['drmongo:mongo-helpers'] = {
  MongoHelpers: MongoHelpers
};

})();

//# sourceMappingURL=drmongo_mongo-helpers.js.map
