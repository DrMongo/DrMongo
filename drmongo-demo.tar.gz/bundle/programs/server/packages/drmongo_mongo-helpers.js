(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var ECMAScript = Package.ecmascript.ECMAScript;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var babelHelpers = Package['babel-runtime'].babelHelpers;
var Promise = Package.promise.Promise;
var Map = Package['ecmascript-collections'].Map;
var Set = Package['ecmascript-collections'].Set;

/* Package-scope variables */
var MongoHelpers;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                     //
// packages/drmongo_mongo-helpers/server/MongoHelpers.js                                               //
//                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                       //
var getConnection = function (data, cb) {                                                              // 1
  var connection = data.connection;                                                                    // 2
  var database = data.database || null;                                                                // 3
  var url = 'mongodb://' + connection.host + ':' + connection.port + (database ? '/' + database : '');
                                                                                                       //
  MongoInternals.NpmModules.mongodb.module(url, function (error, db) {                                 // 6
    if (error) {                                                                                       // 7
      throw new Error(error.message);                                                                  // 8
    } else {                                                                                           //
      cb(null, db);                                                                                    // 10
    }                                                                                                  //
  });                                                                                                  //
};                                                                                                     //
                                                                                                       //
MongoHelpers = {                                                                                       // 16
                                                                                                       //
  getDatabases: function (connection) {                                                                // 18
    var getConnectionWrapper = Meteor.wrapAsync(getConnection);                                        // 19
    var db = getConnectionWrapper({ connection: connection });                                         // 20
                                                                                                       //
    // Use the admin database for the operation                                                        //
    var adminDb = db.admin();                                                                          // 23
                                                                                                       //
    // Get all the available databases                                                                 //
    var listDatabasesWrapper = Meteor.wrapAsync(adminDb.listDatabases);                                // 26
    var databases = listDatabasesWrapper();                                                            // 27
                                                                                                       //
    db.close();                                                                                        // 29
                                                                                                       //
    var databaseNames = [];                                                                            // 31
    _.each(databases.databases, function (value) {                                                     // 32
      if (value.name == 'local' || value.name == 'admin') return false;                                // 33
      databaseNames.push(value.name);                                                                  // 34
    });                                                                                                //
    return databaseNames;                                                                              // 36
  },                                                                                                   //
                                                                                                       //
  getCollections: function (connection, database) {                                                    // 39
    var getConnectionWrapper = Meteor.wrapAsync(getConnection);                                        // 40
    var db = getConnectionWrapper({ connection: connection, database: database });                     // 41
                                                                                                       //
    var collectionNamesWrapper = Meteor.wrapAsync(function (cb) {                                      // 44
      db.collectionNames(function (error, response) {                                                  // 45
        cb(error, response);                                                                           // 46
      });                                                                                              //
    });                                                                                                //
    var collections = collectionNamesWrapper();                                                        // 49
                                                                                                       //
    db.close();                                                                                        // 51
    var collectionNames = [];                                                                          // 52
    _.each(collections, function (value) {                                                             // 53
      if (value.name == 'system.indexes') return false;                                                // 54
      collectionNames.push(value.name);                                                                // 55
    });                                                                                                //
    return collectionNames;                                                                            // 57
  },                                                                                                   //
                                                                                                       //
  createCollection: function (database, collectionName) {                                              // 60
    var getConnectionWrapper = Meteor.wrapAsync(getConnection);                                        // 61
    var db = getConnectionWrapper({ connection: database.connection(), database: database.name });     // 62
                                                                                                       //
    var createCollectionWrapper = Meteor.wrapAsync(function (cb) {                                     // 64
      db.createCollection(collectionName, function (error, response) {                                 // 65
        cb(null, true);                                                                                // 66
      });                                                                                              //
    });                                                                                                //
                                                                                                       //
    var response = createCollectionWrapper();                                                          // 70
                                                                                                       //
    return response;                                                                                   // 72
  }                                                                                                    //
                                                                                                       //
};                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['drmongo:mongo-helpers'] = {
  MongoHelpers: MongoHelpers
};

})();

//# sourceMappingURL=drmongo_mongo-helpers.js.map
