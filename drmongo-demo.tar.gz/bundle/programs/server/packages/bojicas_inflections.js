(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;

(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/bojicas_inflections/packages/bojicas_inflections.js                                         //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
(function () {                                                                                          // 1
                                                                                                        // 2
///////////////////////////////////////////////////////////////////////////////////////////////////     // 3
//                                                                                               //     // 4
// packages/bojicas:inflections/inflections.js                                                   //     // 5
//                                                                                               //     // 6
///////////////////////////////////////////////////////////////////////////////////////////////////     // 7
                                                                                                 //     // 8
// Write your package code here!                                                                 // 1   // 9
this._ = _;                                                                                      // 2   // 10
                                                                                                 // 3   // 11
if (Meteor.isClient) {                                                                           // 4   // 12
  Template.registerHelper('pluralize', function (singular, count, includeCount) {                // 5   // 13
    return _.pluralize(singular, count, includeCount);                                           // 6   // 14
  });                                                                                            // 7   // 15
                                                                                                 // 8   // 16
  Template.registerHelper('singularize', function (word) {                                       // 9   // 17
    return _.singularize(word);                                                                  // 10  // 18
  });                                                                                            // 11  // 19
                                                                                                 // 12  // 20
  Template.registerHelper('ordinalize', function (number) {                                      // 13  // 21
    return _.ordinalize(number);                                                                 // 14  // 22
  });                                                                                            // 15  // 23
                                                                                                 // 16  // 24
  Template.registerHelper('titleize', function (words) {                                         // 17  // 25
    return _.titleize(words);                                                                    // 18  // 26
  });                                                                                            // 19  // 27
}                                                                                                // 20  // 28
                                                                                                 // 21  // 29
///////////////////////////////////////////////////////////////////////////////////////////////////     // 30
                                                                                                        // 31
}).call(this);                                                                                          // 32
                                                                                                        // 33
                                                                                                        // 34
                                                                                                        // 35
                                                                                                        // 36
                                                                                                        // 37
                                                                                                        // 38
(function () {                                                                                          // 39
                                                                                                        // 40
///////////////////////////////////////////////////////////////////////////////////////////////////     // 41
//                                                                                               //     // 42
// packages/bojicas:inflections/vendor/lib/underscore.inflection.js                              //     // 43
//                                                                                               //     // 44
///////////////////////////////////////////////////////////////////////////////////////////////////     // 45
                                                                                                 //     // 46
//  Underscore.inflection.js                                                                     // 1   // 47
//  (c) 2014 Jeremy Ruppel                                                                       // 2   // 48
//  Underscore.inflection is freely distributable under the MIT license.                         // 3   // 49
//  Portions of Underscore.inflection are inspired or borrowed from ActiveSupport                // 4   // 50
//  Version 1.0.0                                                                                // 5   // 51
                                                                                                 // 6   // 52
(function(root, factory) {                                                                       // 7   // 53
  if (typeof define === 'function' && define.amd) {                                              // 8   // 54
    // AMD. Register as an anonymous module.                                                     // 9   // 55
    define(['underscore'], factory);                                                             // 10  // 56
  } else if (typeof exports === 'object') {                                                      // 11  // 57
    // Node. Does not work with strict CommonJS, but                                             // 12  // 58
    // only CommonJS-like environments that support module.exports,                              // 13  // 59
    // like Node.                                                                                // 14  // 60
    module.exports = factory(require('underscore'));                                             // 15  // 61
  } else {                                                                                       // 16  // 62
    // Browser globals (root is window)                                                          // 17  // 63
    factory(root._);                                                                             // 18  // 64
  }                                                                                              // 19  // 65
})(this, function(_, undefined) {                                                                // 20  // 66
  var plurals      = [];                                                                         // 21  // 67
  var singulars    = [];                                                                         // 22  // 68
  var uncountables = [];                                                                         // 23  // 69
                                                                                                 // 24  // 70
  /**                                                                                            // 25  // 71
   * Inflector                                                                                   // 26  // 72
   */                                                                                            // 27  // 73
  var inflector = {                                                                              // 28  // 74
                                                                                                 // 29  // 75
    /**                                                                                          // 30  // 76
     * `gsub` is a method that is just slightly different than our                               // 31  // 77
     * standard `String#replace`. The main differences are that it                               // 32  // 78
     * matches globally every time, and if no substitution is made                               // 33  // 79
     * it returns `null`. It accepts a string for `word` and                                     // 34  // 80
     * `replacement`, and `rule` can be either a string or a regex.                              // 35  // 81
     */                                                                                          // 36  // 82
    gsub: function(word, rule, replacement) {                                                    // 37  // 83
      var pattern = new RegExp(rule.source || rule, 'gi');                                       // 38  // 84
                                                                                                 // 39  // 85
      return pattern.test(word) ? word.replace(pattern, replacement) : null;                     // 40  // 86
    },                                                                                           // 41  // 87
                                                                                                 // 42  // 88
    /**                                                                                          // 43  // 89
     * `plural` creates a new pluralization rule for the inflector.                              // 44  // 90
     * `rule` can be either a string or a regex.                                                 // 45  // 91
     */                                                                                          // 46  // 92
    plural: function(rule, replacement) {                                                        // 47  // 93
      plurals.unshift([rule, replacement]);                                                      // 48  // 94
    },                                                                                           // 49  // 95
                                                                                                 // 50  // 96
    /**                                                                                          // 51  // 97
     * Pluralizes the string passed to it. It also can accept a                                  // 52  // 98
     * number as the second parameter. If a number is provided,                                  // 53  // 99
     * it will pluralize the word to match the number. Optionally,                               // 54  // 100
     * you can pass `true` as a third parameter. If found, this                                  // 55  // 101
     * will include the count with the output.                                                   // 56  // 102
     */                                                                                          // 57  // 103
    pluralize: function(word, count, includeNumber) {                                            // 58  // 104
      var result;                                                                                // 59  // 105
                                                                                                 // 60  // 106
      if (count !== undefined) {                                                                 // 61  // 107
        count = parseFloat(count);                                                               // 62  // 108
        result = (count === 1) ? this.singularize(word) : this.pluralize(word);                  // 63  // 109
        result = (includeNumber) ? [count, result].join(' ') : result;                           // 64  // 110
      }                                                                                          // 65  // 111
      else                                                                                       // 66  // 112
      {                                                                                          // 67  // 113
        if (_(uncountables).include(word)) {                                                     // 68  // 114
          return word;                                                                           // 69  // 115
        }                                                                                        // 70  // 116
                                                                                                 // 71  // 117
        result = word;                                                                           // 72  // 118
                                                                                                 // 73  // 119
        _(plurals).detect(function(rule) {                                                       // 74  // 120
          var gsub = this.gsub(word, rule[0], rule[1]);                                          // 75  // 121
                                                                                                 // 76  // 122
          return gsub ? (result = gsub) : false;                                                 // 77  // 123
        },                                                                                       // 78  // 124
        this);                                                                                   // 79  // 125
      }                                                                                          // 80  // 126
                                                                                                 // 81  // 127
      return result;                                                                             // 82  // 128
    },                                                                                           // 83  // 129
                                                                                                 // 84  // 130
    /**                                                                                          // 85  // 131
     * `singular` creates a new singularization rule for the                                     // 86  // 132
     * inflector. `rule` can be either a string or a regex.                                      // 87  // 133
     */                                                                                          // 88  // 134
    singular: function(rule, replacement) {                                                      // 89  // 135
      singulars.unshift([rule, replacement]);                                                    // 90  // 136
    },                                                                                           // 91  // 137
                                                                                                 // 92  // 138
    /**                                                                                          // 93  // 139
     * `singularize` returns the singular version of the plural                                  // 94  // 140
     * passed to it.                                                                             // 95  // 141
     */                                                                                          // 96  // 142
    singularize: function(word) {                                                                // 97  // 143
      if (_(uncountables).include(word)) {                                                       // 98  // 144
        return word;                                                                             // 99  // 145
      }                                                                                          // 100
                                                                                                 // 101
      var result = word;                                                                         // 102
                                                                                                 // 103
      _(singulars).detect(function(rule) {                                                       // 104
        var gsub = this.gsub(word, rule[0], rule[1]);                                            // 105
                                                                                                 // 106
        return gsub ? (result = gsub) : false;                                                   // 107
      },                                                                                         // 108
      this);                                                                                     // 109
                                                                                                 // 110
      return result;                                                                             // 111
    },                                                                                           // 112
                                                                                                 // 113
    /**                                                                                          // 114
     * `irregular` is a shortcut method to create both a                                         // 115
     * pluralization and singularization rule for the word at                                    // 116
     * the same time. You must supply both the singular form                                     // 117
     * and the plural form as explicit strings.                                                  // 118
     */                                                                                          // 119
    irregular: function(singular, plural) {                                                      // 120
      this.plural('\\b' + singular + '\\b', plural);                                             // 121
      this.singular('\\b' + plural + '\\b', singular);                                           // 122
    },                                                                                           // 123
                                                                                                 // 124
    /**                                                                                          // 125
     * `uncountable` creates a new uncountable rule for `word`.                                  // 126
     * Uncountable words do not get pluralized or singularized.                                  // 127
     */                                                                                          // 128
    uncountable: function(word) {                                                                // 129
      uncountables.unshift(word);                                                                // 130
    },                                                                                           // 131
                                                                                                 // 132
    /**                                                                                          // 133
     * `ordinalize` adds an ordinal suffix to `number`.                                          // 134
     */                                                                                          // 135
    ordinalize: function(number) {                                                               // 136
      if (isNaN(number)) {                                                                       // 137
        return number;                                                                           // 138
      }                                                                                          // 139
                                                                                                 // 140
      number = number.toString();                                                                // 141
      var lastDigit = number.slice(-1);                                                          // 142
      var lastTwoDigits = number.slice(-2);                                                      // 143
                                                                                                 // 144
      if (lastTwoDigits === '11' || lastTwoDigits === '12' || lastTwoDigits === '13') {          // 145
        return number + 'th';                                                                    // 146
      }                                                                                          // 147
                                                                                                 // 148
      switch (lastDigit) {                                                                       // 149
        case '1':                                                                                // 150
          return number + 'st';                                                                  // 151
        case '2':                                                                                // 152
          return number + 'nd';                                                                  // 153
        case '3':                                                                                // 154
          return number + 'rd';                                                                  // 155
        default:                                                                                 // 156
          return number + 'th';                                                                  // 157
      }                                                                                          // 158
    },                                                                                           // 159
                                                                                                 // 160
    /**                                                                                          // 161
     * `titleize` capitalizes the first letter of each word in                                   // 162
     * the string `words`. It preserves the existing whitespace.                                 // 163
     */                                                                                          // 164
    titleize: function(words) {                                                                  // 165
      if (typeof words !== 'string') {                                                           // 166
        return words;                                                                            // 167
      }                                                                                          // 168
                                                                                                 // 169
      return words.replace(/\S+/g, function(word) {                                              // 170
        return word.charAt(0).toUpperCase() + word.slice(1);                                     // 171
      });                                                                                        // 172
    },                                                                                           // 173
                                                                                                 // 174
    /**                                                                                          // 175
     * Resets the inflector's rules to their initial state,                                      // 176
     * clearing out any custom rules that have been added.                                       // 177
     */                                                                                          // 178
    resetInflections: function() {                                                               // 179
      plurals      = [];                                                                         // 180
      singulars    = [];                                                                         // 181
      uncountables = [];                                                                         // 182
                                                                                                 // 183
      this.plural(/$/,                         's');                                             // 184
      this.plural(/s$/,                        's');                                             // 185
      this.plural(/(ax|test)is$/,              '$1es');                                          // 186
      this.plural(/(octop|vir)us$/,            '$1i');                                           // 187
      this.plural(/(octop|vir)i$/,             '$1i');                                           // 188
      this.plural(/(alias|status)$/,           '$1es');                                          // 189
      this.plural(/(bu)s$/,                    '$1ses');                                         // 190
      this.plural(/(buffal|tomat)o$/,          '$1oes');                                         // 191
      this.plural(/([ti])um$/,                 '$1a');                                           // 192
      this.plural(/([ti])a$/,                  '$1a');                                           // 193
      this.plural(/sis$/,                      'ses');                                           // 194
      this.plural(/(?:([^f])fe|([lr])?f)$/,     '$1$2ves');                                      // 195
      this.plural(/(hive)$/,                   '$1s');                                           // 196
      this.plural(/([^aeiouy]|qu)y$/,          '$1ies');                                         // 197
      this.plural(/(x|ch|ss|sh)$/,             '$1es');                                          // 198
      this.plural(/(matr|vert|ind)(?:ix|ex)$/, '$1ices');                                        // 199
      this.plural(/([m|l])ouse$/,              '$1ice');                                         // 200
      this.plural(/([m|l])ice$/,               '$1ice');                                         // 201
      this.plural(/^(ox)$/,                    '$1en');                                          // 202
      this.plural(/^(oxen)$/,                  '$1');                                            // 203
      this.plural(/(quiz)$/,                   '$1zes');                                         // 204
                                                                                                 // 205
      this.singular(/s$/,                                                            '');        // 206
      this.singular(/(n)ews$/,                                                       '$1ews');   // 207
      this.singular(/([ti])a$/,                                                      '$1um');    // 208
      this.singular(/((a)naly|(b)a|(d)iagno|(p)arenthe|(p)rogno|(s)ynop|(t)he)ses$/, '$1$2sis'); // 209
      this.singular(/(^analy)ses$/,                                                  '$1sis');   // 210
      this.singular(/([^f])ves$/,                                                    '$1fe');    // 211
      this.singular(/(hive)s$/,                                                      '$1');      // 212
      this.singular(/(tive)s$/,                                                      '$1');      // 213
      this.singular(/([lr])ves$/,                                                    '$1f');     // 214
      this.singular(/([^aeiouy]|qu)ies$/,                                            '$1y');     // 215
      this.singular(/(s)eries$/,                                                     '$1eries'); // 216
      this.singular(/(m)ovies$/,                                                     '$1ovie');  // 217
      this.singular(/(x|ch|ss|sh)es$/,                                               '$1');      // 218
      this.singular(/([m|l])ice$/,                                                   '$1ouse');  // 219
      this.singular(/(bus)es$/,                                                      '$1');      // 220
      this.singular(/(o)es$/,                                                        '$1');      // 221
      this.singular(/(shoe)s$/,                                                      '$1');      // 222
      this.singular(/(cris|ax|test)es$/,                                             '$1is');    // 223
      this.singular(/(octop|vir)i$/,                                                 '$1us');    // 224
      this.singular(/(alias|status)es$/,                                             '$1');      // 225
      this.singular(/^(ox)en/,                                                       '$1');      // 226
      this.singular(/(vert|ind)ices$/,                                               '$1ex');    // 227
      this.singular(/(matr)ices$/,                                                   '$1ix');    // 228
      this.singular(/(quiz)zes$/,                                                    '$1');      // 229
      this.singular(/(database)s$/,                                                  '$1');      // 230
                                                                                                 // 231
      this.irregular('person', 'people');                                                        // 232
      this.irregular('man',    'men');                                                           // 233
      this.irregular('child',  'children');                                                      // 234
      this.irregular('sex',    'sexes');                                                         // 235
      this.irregular('move',   'moves');                                                         // 236
      this.irregular('cow',    'kine');                                                          // 237
                                                                                                 // 238
      this.uncountable('equipment');                                                             // 239
      this.uncountable('information');                                                           // 240
      this.uncountable('rice');                                                                  // 241
      this.uncountable('money');                                                                 // 242
      this.uncountable('species');                                                               // 243
      this.uncountable('series');                                                                // 244
      this.uncountable('fish');                                                                  // 245
      this.uncountable('sheep');                                                                 // 246
      this.uncountable('jeans');                                                                 // 247
                                                                                                 // 248
      return this;                                                                               // 249
    }                                                                                            // 250
  };                                                                                             // 251
                                                                                                 // 252
  /**                                                                                            // 253
   * Underscore integration                                                                      // 254
   */                                                                                            // 255
  _.mixin(inflector.resetInflections());                                                         // 256
                                                                                                 // 257
  return inflector;                                                                              // 258
});                                                                                              // 259
                                                                                                 // 260
///////////////////////////////////////////////////////////////////////////////////////////////////     // 307
                                                                                                        // 308
}).call(this);                                                                                          // 309
                                                                                                        // 310
//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['bojicas:inflections'] = {};

})();

//# sourceMappingURL=bojicas_inflections.js.map
