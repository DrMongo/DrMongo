(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var Mousetrap;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/mousetrap_mousetrap/packages/mousetrap_mousetrap.js      //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mousetrap:mousetrap'] = {
  Mousetrap: Mousetrap
};

})();

//# sourceMappingURL=mousetrap_mousetrap.js.map
